import numpy as np


class CostFunction:
    @staticmethod
    def distributed_aggregative(z, bary, gamma, r0, r, d, N):
        """
        Compute cost and gradient for distributed aggregative formation control
        
        Cost function:
            J_i = gamma * ||z_i - r_i||^2 + (1-gamma) * ||bary_i - r0_i||^2
        
        Where:
            - First term: Target attainment (robot tries to reach its target)
            - Second term: Formation keeping (barycenter tracking)
        
        Args:
            z: Agent's current position (d,)
            bary: Agent's barycenter estimate (d,) - this is s_i in the algorithm
            gamma: Trade-off parameter [0,1] - higher = more target tracking, lower = more formation
            r0: Desired barycenter for this agent (d,)
            r: Target position for this agent (d,)
            d: Dimension (typically 2 for 2D space)
            N: Total number of agents
            
        Returns:
            cost: Scalar cost value
            grad_1: Gradient w.r.t. position z (includes both terms) (d,)
            grad_2: Gradient w.r.t. aggregate variable (barycenter) (d,)
        """
        
        # Compute differences
        target_dist = z - r           # Distance from current position to target
        bary_dist = bary - r0         # Distance from barycenter estimate to desired barycenter
        
        # Cost computation
        # Term 1: gamma * ||z - r||^2 (target attainment)
        # Term 2: (1-gamma) * ||bary - r0||^2 (formation keeping)
        cost = gamma * (np.linalg.norm(target_dist)**2) + (1 - gamma) * (np.linalg.norm(bary_dist)**2)
        
        # Gradient computation
        # grad_1: Full gradient w.r.t. z (includes contribution from barycenter term)
        # ∂J/∂z = 2*gamma*(z - r) + (1-gamma)*(2/N)*(bary - r0)
        # The (2/N) factor comes from: ∂(||bary/N - r0||^2)/∂z = (2/N)*(bary/N - r0)
        grad_1 = 2 * gamma * target_dist + (1 - gamma) * (2.0 / N) * bary_dist
        
        # grad_2: Gradient of aggregate term only (used for gradient tracking)
        # This is ∇_σ f_i(z_i, σ) where σ is the aggregate variable (barycenter)
        # ∂J/∂bary = (1-gamma) * 2 * (bary - r0)
        grad_2 = (1 - gamma) * (2 * bary_dist)
        
        return cost, grad_1, grad_2