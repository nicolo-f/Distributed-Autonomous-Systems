import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray as msg_float
from .cost_function import CostFunction


class RobotAgent(Node):
    def __init__(self):
        super().__init__(
            "robot_agent",
            allow_undeclared_parameters=True,
            automatically_declare_parameters_from_overrides=True,
        )

        # Get parameters from launcher
        self.agent_id = self.get_parameter("agent_id").value
        self.N = self.get_parameter("N").value  # Total number of agents
        self.d = self.get_parameter("d").value  # Dimension (2D)
        self.dt = self.get_parameter("dt").value  # Time step
        self.alpha = self.get_parameter("alpha").value  # Step size
        self.gamma = self.get_parameter("gamma").value  # Trade-off parameter
        
        # Initial positions
        self.z = np.array(self.get_parameter("z_init").value)  # [x, y]
        self.r0 = np.array(self.get_parameter("r0").value)  # Desired barycenter
        self.target = np.array(self.get_parameter("target").value)  # Target position
        
        # Get adjacency matrix row for this agent
        self.A_row = np.array(self.get_parameter("A_row").value)
        self.neighbors = np.nonzero(self.A_row)[0].tolist()
        
        # Remove self from neighbors list if present
        if self.agent_id in self.neighbors:
            self.neighbors.remove(self.agent_id)
        
        # State variables
        self.s = self.z.copy()  # Local barycenter estimate
        self.v = np.zeros(self.d)  # Local gradient estimate
        
        # Initialize gradient
        _, _, self.v = CostFunction.distributed_aggregative(
            self.z, self.s, self.gamma, self.r0, self.target, self.d, self.N
        )
        
        # Neighbor data storage
        self.neighbor_z = {j: np.zeros(self.d) for j in self.neighbors}
        self.neighbor_s = {j: np.zeros(self.d) for j in self.neighbors}
        self.neighbor_v = {j: np.zeros(self.d) for j in self.neighbors}
        self.data_received = {j: False for j in self.neighbors}
        
        # Publishers
        self.pub_position = self.create_publisher(
            msg_float, f"/agent_{self.agent_id}/position", 10
        )
        self.pub_barycenter = self.create_publisher(
            msg_float, f"/agent_{self.agent_id}/barycenter", 10
        )
        self.pub_gradient = self.create_publisher(
            msg_float, f"/agent_{self.agent_id}/gradient", 10
        )
        self.cost_pub = self.create_publisher(
            msg_float, f"/agent_{self.agent_id}/cost", 10)

        
        # Subscribers for neighbors
        for j in self.neighbors:
            self.create_subscription(
                msg_float, f"/agent_{j}/position",
                lambda msg, j=j: self.neighbor_position_callback(msg, j), 10
            )
            self.create_subscription(
                msg_float, f"/agent_{j}/barycenter",
                lambda msg, j=j: self.neighbor_barycenter_callback(msg, j), 10
            )
            self.create_subscription(
                msg_float, f"/agent_{j}/gradient",
                lambda msg, j=j: self.neighbor_gradient_callback(msg, j), 10
            )
        
        # Timer for control loop
        self.timer = self.create_timer(self.dt, self.control_callback)
        self.iteration = 0
        
        self.get_logger().info(
            f"Agent {self.agent_id} initialized at position {self.z}, "
            f"target: {self.target}, neighbors: {self.neighbors}"
        )

    def neighbor_position_callback(self, msg, neighbor_id):
        """Receive neighbor's position"""
        self.neighbor_z[neighbor_id] = np.array(msg.data)
        self.data_received[neighbor_id] = True

    def neighbor_barycenter_callback(self, msg, neighbor_id):
        """Receive neighbor's barycenter estimate"""
        self.neighbor_s[neighbor_id] = np.array(msg.data)

    def neighbor_gradient_callback(self, msg, neighbor_id):
        """Receive neighbor's gradient estimate"""
        self.neighbor_v[neighbor_id] = np.array(msg.data)

    def control_callback(self):
        """Main control loop - runs aggregative tracking algorithm"""
        
        # Wait for all neighbor data (skip first few iterations)
        if self.iteration > 0 and len(self.neighbors) > 0:
            if not all(self.data_received.values()):
                return


        # Store previous values
        z_old = self.z.copy()
        
        # Compute local cost and gradients
        cost, grad_1, grad_2 = CostFunction.distributed_aggregative(
            self.z, self.s, self.gamma, self.r0, self.target, self.d, self.N
        )

        self.current_cost = cost
                
        # Update position: z_{k+1} = z_k - alpha * (grad_1 + v_k)
        self.z = self.z - self.alpha * (grad_1 + self.v)
        
        # Consensus updates for s and v
        #check self loops here
        s_consensus = self.A_row[self.agent_id] * self.s
        v_consensus = self.A_row[self.agent_id] * self.v
        
        for j in self.neighbors:
            s_consensus += self.A_row[j] * self.neighbor_s[j]
            v_consensus += self.A_row[j] * self.neighbor_v[j]
        
        # Update barycenter estimate: s_{k+1} = consensus + (z_{k+1} - z_k)
        self.s = s_consensus + (self.z - z_old)
        
        # Compute new gradient for innovation
        _, _, grad_2_next = CostFunction.distributed_aggregative(
            self.z, self.s, self.gamma, self.r0, self.target, self.d, self.N
        )
        
        # Update gradient estimate: v_{k+1} = consensus + (grad_2_next - grad_2)
        self.v = v_consensus + (grad_2_next - grad_2)
        
        # Publish state
        self.publish_state()
        
        # Reset data received flags
        self.data_received = {j: False for j in self.neighbors}
        self.iteration += 1
        
        if self.iteration % 50 == 0:
            error = np.linalg.norm(self.z - self.target)
            self.get_logger().info(
                f"Agent {self.agent_id} iter {self.iteration}: "
                f"pos=[{self.z[0]:.2f}, {self.z[1]:.2f}], "
                f"error={error:.4f}"
            )

    def publish_state(self):
        """Publish agent's state to neighbors"""
        msg_z = msg_float()
        msg_z.data = self.z.tolist()
        self.pub_position.publish(msg_z)
        
        msg_s = msg_float()
        msg_s.data = self.s.tolist()
        self.pub_barycenter.publish(msg_s)
        
        msg_v = msg_float()
        msg_v.data = self.v.tolist()
        self.pub_gradient.publish(msg_v)

        cost_msg = msg_float()
        cost_msg.data = [float(self.current_cost)]
        self.cost_pub.publish(cost_msg)


def main(args=None):
    rclpy.init(args=args)
    agent = RobotAgent()
    
    try:
        rclpy.spin(agent)
    except KeyboardInterrupt:
        agent.get_logger().info("Agent stopped cleanly")
    finally:
        rclpy.shutdown()


if __name__ == "__main__":
    main()