import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray as msg_float
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation


class MonitorNode(Node):
    def __init__(self):
        super().__init__(
            "monitor_node",
            allow_undeclared_parameters=True,
            automatically_declare_parameters_from_overrides=True,
        )
        
        self.N = self.get_parameter("N").value
        self.d = self.get_parameter("d").value
        self.max_iters = self.get_parameter("max_iters").value
        
        # Get target positions
        self.targets = []
        for i in range(self.N):
            target = self.get_parameter(f"target_{i}").value
            self.targets.append(np.array(target))
        
        # Storage for all agents' data
        self.positions = {i: [] for i in range(self.N)}
        self.barycenters = {i: [] for i in range(self.N)}
        self.latest_positions = {i: np.zeros(self.d) for i in range(self.N)}
        self.latest_barycenters = {i: np.zeros(self.d) for i in range(self.N)}
        self.costs = {i: [] for i in range(self.N)}
        self.latest_costs = {i: 0.0 for i in range(self.N)}
        
        # Cost history for plotting
        self.total_cost_history = []
        self.iteration_history = []

        # Subscribe to all agents
        for i in range(self.N):
            self.create_subscription(
                msg_float, f"/agent_{i}/position",
                lambda msg, i=i: self.position_callback(msg, i), 10
            )
            self.create_subscription(
                msg_float, f"/agent_{i}/barycenter",
                lambda msg, i=i: self.barycenter_callback(msg, i), 10
            )
            self.create_subscription(
                msg_float, f"/agent_{i}/cost",
                lambda msg, i=i: self.cost_callback(msg, i), 10
            )
        
        # Timer for monitoring
        self.timer = self.create_timer(1.0, self.monitor_callback)
        self.iteration_count = 0
        
        # Setup real-time plotting
        plt.ion()
        self.fig, (self.ax1, self.ax2) = plt.subplots(2, 1, figsize=(10, 8))
        self.fig.suptitle('Cost Function Evolution')
        
        # Setup axes
        self.ax1.set_xlabel('Iteration')
        self.ax1.set_ylabel('Total Cost')
        self.ax1.set_title('Total System Cost')
        self.ax1.grid(True)
        
        self.ax2.set_xlabel('Iteration')
        self.ax2.set_ylabel('Individual Cost')
        self.ax2.set_title('Individual Agent Costs')
        self.ax2.grid(True)
        
        # Initialize plot lines
        self.line_total, = self.ax1.plot([], [], 'b-', linewidth=2, label='Total Cost')
        self.line_total_ma, = self.ax1.plot([], [], 'r--', linewidth=2, label='Moving Avg (10)')
        self.ax1.legend()
        
        self.agent_lines = {}
        colors = plt.cm.tab10(np.linspace(0, 1, self.N))
        for i in range(self.N):
            line, = self.ax2.plot([], [], '-', linewidth=1.5, color=colors[i], label=f'Agent {i}')
            self.agent_lines[i] = line
        self.ax2.legend()
        
        plt.tight_layout()
        
        self.get_logger().info(f"Monitor node initialized, tracking {self.N} agents")

    def position_callback(self, msg, agent_id):
        pos = np.array(msg.data)
        self.positions[agent_id].append(pos)
        self.latest_positions[agent_id] = pos

    def barycenter_callback(self, msg, agent_id):
        bary = np.array(msg.data)
        self.barycenters[agent_id].append(bary)
        self.latest_barycenters[agent_id] = bary
    
    def cost_callback(self, msg, agent_id):
        cost = msg.data[0]
        self.costs[agent_id].append(cost)
        self.latest_costs[agent_id] = cost

    def monitor_callback(self):
        """Periodically print and plot cost values"""
        # Print individual costs
        cost_values = [f"Agent {i}: {self.latest_costs[i]:.6f}" for i in range(self.N)]
        cost_str = ", ".join(cost_values)
        
        # Compute total cost
        total_cost = sum(self.latest_costs.values())
        
        # Store for plotting
        self.total_cost_history.append(total_cost)
        self.iteration_history.append(self.iteration_count)
        
        # Compute tracking errors for reference
        tracking_errors = [
            np.linalg.norm(self.latest_positions[i] - self.targets[i])
            for i in range(self.N)
        ]
        mean_tracking_error = np.mean(tracking_errors)
        
        self.get_logger().info(
            f"Iter {self.iteration_count}: "
            f"Total Cost={total_cost:.6f}, "
            f"Individual: [{cost_str}], "
            f"Mean Tracking Error={mean_tracking_error:.4f}"
        )
        
        # Update plots
        self.update_plots()
        
        self.iteration_count += 1
        
        # Check for convergence
        if len(self.total_cost_history) > 10:
            recent_costs = self.total_cost_history[-10:]
            cost_variance = np.var(recent_costs)
            cost_trend = recent_costs[-1] - recent_costs[0]
            
            self.get_logger().info(
                f"Cost trend (last 10): Δ={cost_trend:.6f}, Var={cost_variance:.6e}"
            )
            
            if cost_variance < 1e-2 :
                self.get_logger().info("✅ Cost has stabilized!")
                self.get_logger().info("Shutting down all nodes and stopping the monitor.")
                plt.close('all')  # Close the plots
                rclpy.shutdown()  # Shutdown ROS 2

    def update_plots(self):
        """Update the real-time cost plots"""
        if len(self.iteration_history) == 0:
            return
        
        # Update total cost plot
        self.line_total.set_data(self.iteration_history, self.total_cost_history)
        
        # Update moving average
        if len(self.total_cost_history) >= 10:
            ma_window = 10
            moving_avg = np.convolve(self.total_cost_history, 
                                     np.ones(ma_window)/ma_window, 
                                     mode='valid')
            ma_iterations = self.iteration_history[ma_window-1:]
            self.line_total_ma.set_data(ma_iterations, moving_avg)
        
        # Update individual agent costs
        for i in range(self.N):
            if len(self.costs[i]) > 0:
                iterations = list(range(len(self.costs[i])))
                self.agent_lines[i].set_data(iterations, self.costs[i])
        
        # Rescale axes
        self.ax1.relim()
        self.ax1.autoscale_view()
        self.ax2.relim()
        self.ax2.autoscale_view()
        
        # Redraw
        self.fig.canvas.draw()
        self.fig.canvas.flush_events()


def main(args=None):
    rclpy.init(args=args)
    monitor = MonitorNode()
    
    try:
        rclpy.spin(monitor)
    except KeyboardInterrupt:
        monitor.get_logger().info("Monitor stopped")
        plt.close('all')
    finally:
        rclpy.shutdown()


if __name__ == "__main__":
    main()






























# import numpy as np
# import rclpy
# from rclpy.node import Node
# from std_msgs.msg import Float32MultiArray as msg_float
# import matplotlib.pyplot as plt
# from matplotlib.animation import FuncAnimation


# class MonitorNode(Node):
#     def __init__(self):
#         super().__init__(
#             "monitor_node",
#             allow_undeclared_parameters=True,
#             automatically_declare_parameters_from_overrides=True,
#         )
        
#         self.N = self.get_parameter("N").value
#         self.d = self.get_parameter("d").value
#         self.max_iters = self.get_parameter("max_iters").value
        
#         # Get target positions
#         self.targets = []
#         for i in range(self.N):
#             target = self.get_parameter(f"target_{i}").value
#             self.targets.append(np.array(target))
        
#         # Storage for all agents' data
#         self.positions = {i: [] for i in range(self.N)}
#         self.barycenters = {i: [] for i in range(self.N)}
#         self.latest_positions = {i: np.zeros(self.d) for i in range(self.N)}
#         self.latest_barycenters = {i: np.zeros(self.d) for i in range(self.N)}
#         self.costs = {i: [] for i in range(self.N)}
#         self.latest_costs = {i: 0.0 for i in range(self.N)}

#         # Subscribe to all agents
#         for i in range(self.N):
#             self.create_subscription(
#                 msg_float, f"/agent_{i}/position",
#                 lambda msg, i=i: self.position_callback(msg, i), 10
#             )
#             self.create_subscription(
#                 msg_float, f"/agent_{i}/barycenter",
#                 lambda msg, i=i: self.barycenter_callback(msg, i), 10
#             )
#             self.create_subscription(
#                 msg_float, f"/agent_{i}/cost",
#                 lambda msg, i=i: self.cost_callback(msg, i), 10
#             )
        
#         # Timer for monitoring
#         self.timer = self.create_timer(1.0, self.monitor_callback)
#         self.iteration_count = 0
        
#         self.get_logger().info(f"Monitor node initialized, tracking {self.N} agents")

#     def position_callback(self, msg, agent_id):
#         pos = np.array(msg.data)
#         self.positions[agent_id].append(pos)
#         self.latest_positions[agent_id] = pos

#     def barycenter_callback(self, msg, agent_id):
#         bary = np.array(msg.data)
#         self.barycenters[agent_id].append(bary)
#         self.latest_barycenters[agent_id] = bary
    
#     def cost_callback(self, msg, agent_id):
#         cost = msg.data[0]
#         self.costs[agent_id].append(cost)
#         self.latest_costs[agent_id] = cost

#     def monitor_callback(self):
#         """Periodically print cost values"""
#         # Print individual costs
#         cost_values = [f"Agent {i}: {self.latest_costs[i]:.6f}" for i in range(self.N)]
#         cost_str = ", ".join(cost_values)
        
#         # Compute total cost
#         total_cost = sum(self.latest_costs.values())
       
        
#         # # Compute barycenter consensus
#         # latest_bary_list = [self.latest_barycenters[i] for i in range(self.N)]
#         # barycenter_mean = np.mean(latest_bary_list, axis=0)
#         # barycenter_consensus = np.mean([
#         #     np.linalg.norm(bary - barycenter_mean)
#         #     for bary in latest_bary_list
#         # ])
        
#         # Compute tracking errors for reference
#         tracking_errors = [
#             np.linalg.norm(self.latest_positions[i] - self.targets[i])
#             for i in range(self.N)
#         ]
#         #mean_tracking_error = np.mean(tracking_errors)
        
#         self.get_logger().info(
#             f"Iter {self.iteration_count}: "
#             f"Total Cost={total_cost:.6f}, "
#             f"Individual: [{cost_str}],\n "
#             f"Tracking Errors={tracking_errors}\n"
#         )
        
#         self.iteration_count += 1
        
#         # Optional: Check for convergence based on cost stabilization
#         if len(self.costs[0]) > 10:
#             recent_total_costs = [sum(self.costs[i][-10:]) for i in range(self.N)]
#             cost_variance = np.var(recent_total_costs)
#             if cost_variance < 1e-8 and total_cost < 1.0:
#                 self.get_logger().info("✅ Cost has stabilized!")

# def main(args=None):
#     rclpy.init(args=args)
#     monitor = MonitorNode()
    
#     try:
#         rclpy.spin(monitor)
#     except KeyboardInterrupt:
#         monitor.get_logger().info("Monitor stopped")
#     finally:
#         rclpy.shutdown()


# if __name__ == "__main__":
#     main()