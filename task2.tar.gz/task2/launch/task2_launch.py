from launch import LaunchDescription
from launch_ros.actions import Node
import numpy as np


def generate_launch_description():
    """Generate launch description for distributed formation control"""
    
    np.random.seed(0)
    
    # Parameters
    N = 8  # Number of robots
    d = 2  # Dimension
    dt = 0.1  # Time step (seconds)
    alpha = 1e-2  # Step size
    gamma = 0.7  # Trade-off parameter
    target_std = 2.0  # Standard deviation for target generation
    p_er = 0.5  # Erdos-Renyi connection probability
    max_iters = 200
    
    # Generate random initial positions and targets
    robot_positions = np.random.uniform(low=0, high=10, size=(N, d))
    target_positions = robot_positions + np.random.normal(0, target_std, size=(N, d))
    
    # Desired barycenter (Option 3: each agent maintains its initial position as desired)
    r0 = robot_positions.copy()
    
    # Create adjacency matrix
    A = create_metropolis_hastings_matrix(N, p_er)
    
    # Print information
    print("\n" + "="*60)
    print("DISTRIBUTED FORMATION CONTROL - ROS2 Launch")
    print("="*60)
    print(f"Number of agents: {N}")
    print(f"Dimension: {d}")
    print(f"Time step: {dt} s")
    print(f"Step size (alpha): {alpha}")
    print(f"Trade-off (gamma): {gamma}")
    print(f"Max iterations: {max_iters}")
    print("\nInitial positions:")
    for i in range(N):
        print(f"  Agent {i}: {robot_positions[i]}")
    print("\nTarget positions:")
    for i in range(N):
        print(f"  Agent {i}: {target_positions[i]}")
    print("="*60 + "\n")
    
    # Create nodes for each agent
    nodes = []
    
    for i in range(N):
        node = Node(
            package='task2',
            executable='robot_agent',
            name=f'agent_{i}',
            namespace='',
            parameters=[{
                'agent_id': i,
                'N': N,
                'd': d,
                'dt': dt,
                'alpha': alpha,
                'gamma': gamma,
                'z_init': robot_positions[i].tolist(),
                'r0': r0[i].tolist(),
                'target': target_positions[i].tolist(),
                'A_row': A[i].tolist(),
            }],
            output='screen',
            prefix = f'xterm -title "Agent {i}" -fa "Monospace" -fs -hold -e',
        )
        nodes.append(node)
    
    # Add monitor node
    monitor_params = {
        'N': N,
        'd': d,
        'max_iters': max_iters,
    }
    
    # Add target positions to monitor parameters
    for i in range(N):
        monitor_params[f'target_{i}'] = target_positions[i].tolist()
    
    monitor = Node(
        package='task2',
        executable='monitor_node',
        name='monitor',
        namespace='',
        parameters=[monitor_params],
        output='screen'
    )
    nodes.append(monitor)
    
    return LaunchDescription(nodes)


def create_metropolis_hastings_matrix(N, p_er):
    """
    Create doubly-stochastic adjacency matrix using Metropolis-Hastings weights
    
    Args:
        N: Number of agents
        p_er: Edge probability for Erdos-Renyi graph
        
    Returns:
        A: NxN doubly-stochastic matrix
    """
    # Create Erdos-Renyi graph adjacency
    Adj = np.zeros((N, N))
    for i in range(N):
        for j in range(i+1, N):
            if np.random.rand() < p_er:
                Adj[i, j] = 1
                Adj[j, i] = 1
    
    # Add self-loops
    Adj += np.eye(N)
    
    # Check connectivity (simple check - should be improved)
    test = np.linalg.matrix_power(Adj, N)
    if not np.all(test > 0):
        print("Warning: Graph may not be strongly connected!")
    
    # Compute Metropolis-Hastings weights
    A = np.zeros((N, N))
    degrees = np.sum(Adj, axis=1)
    
    for i in range(N):
        for j in range(N):
            if i != j and Adj[i, j] > 0:
                A[i, j] = 1.0 / (1.0 + max(degrees[i], degrees[j]))
        
        # Self-loop weight to make row sum to 1
        A[i, i] = 1.0 - np.sum(A[i, :])
    
    # Verify doubly-stochastic property
    row_sums = np.sum(A, axis=1)
    col_sums = np.sum(A, axis=0)
    
    assert np.allclose(row_sums, 1.0), f"Rows don't sum to 1: {row_sums}"
    assert np.allclose(col_sums, 1.0), f"Columns don't sum to 1: {col_sums}"
    
    return A